"""Split-K TDM refill for the MXFP8 x MXFP8 4x4-cluster GEMM.

The deferred fix in ``kernels_deferred.py`` is race-free but slow: a two-slot
ring gives tile t's refill exactly one tile of lead time, and the trace at
4096/4096/65536 shows 69,465 stall cycles parked on ``s_wait_tensorcnt``
waiting for that refill to land.  Adding a third K256 slot would restore the
lead but needs 147,712 more bytes of LDS against roughly 32,000 free.

Split-K buys the lead without buying LDS.  MXFP8 already consumes each K256
tile as two K128 halves, because that is the scaled-WMMA instruction shape, so
the tile splits along a boundary the reader already respects.  Holding the
halves as four K128 half-slots rather than two K256 slots doubles the number of
independent refill targets at the same footprint.  Each half-step then refills
the half-slot drained one half-step ago, lifting the lead from 1.0 to 1.5
tiles.

The four half-slots are one indexed ring, not four separately allocated
buffers.  Half-slot h holds the low half of tile h/2 when h is even and the
high half when odd, so with ``base = 2 * t`` tile t's halves are base and
base+1, and the schedule is:

    half-step 0   read base+0   refill base+3 with tile t+1 high
    half-step 1   read base+1   refill base+4 with tile t+2 low

Spelling every index as one SSA base plus a constant, reduced by a constant
modulus, is what membar's buffer index analysis recognises.  It then proves
base+3 disjoint from base+0 within a stage and sees that base+4 reduces to
base, so the second refill aliases the read above it.  The earlier version of
this file used eight separate allocations, which defeated the analysis
entirely: refill and read were simply different buffers, so nothing could be
compared and no barrier was ever considered.

Lead time is three half-steps: base+3 is issued at half-step 2t and read at
2t+3, base+4 at 2t+1 and read at 2t+4.

Legible indices are necessary but not sufficient here.  Both refills target a
half-slot whose last reader was the immediately preceding half-step, and the
ring is too shallow to give them more separation, so each carries its own
adjacent ``cluster.arrive()`` / ``cluster.wait()`` pair as the deferred K256
form does at tile granularity.  That pair is signalled by warp 0 alone and
orders CTAs rather than waves, and membar, seeing the alias, treats the wait's
barrier as covering it and adds nothing.  With the indices legible and no
further barrier the kernel still failed 2 of 120 runs at 2048/2048/4096 with
sparse torn-buffer mismatches, the same rate as the eight-allocation version.
Each half-step is therefore split between its refill and its reads, which puts
a stage boundary in that gap: 120 of 120 runs clean.

The cost is TDM transfer granularity.  Each refill moves 128 contiguous bytes
per row instead of 256, doubling GL2 requests for the same bytes.  Whether the
recovered lead outweighs that is the question this file exists to measure.  It
does not: 340 us against 293 for the deferred K256 form at 4096/4096/65536.

A half-slot must be a whole K128 buffer, indexed, and not a slice of a K256
one: a TDM write into a *slice* of a padded K256 buffer inherits the parent's
padded row stride instead of presenting a contiguous block, and produces
garbage.  Indexing the leading dimension of a K128-layout ring is fine.
"""

import argparse
import sys
from pathlib import Path

import torch
import triton
from triton._C.libtriton.gluon_ir import make_cga_layout
from triton.experimental import gluon
import triton.experimental.gluon.language as gl
from triton.experimental.gluon.language.amd.gfx1250 import tdm

GEMM_DIR = (Path(__file__).resolve().parents[2] / "third_party" / "amd"
            / "python" / "examples" / "gluon" / "gfx1250_gemm")
if str(GEMM_DIR) not in sys.path:
    sys.path.insert(0, str(GEMM_DIR))

from kernels_deferred import (  # noqa: E402
    AGPR_ATTRS,
    MXScaleTensor,
    init_data,
    make_trig_tensor,
    mxfp8_load_scale,
    mxfp8_tdm_store_serial_n2,
    pack_scale,
    run_benchmark,
    snapshot_cluster_wait,
    snapshot_get_xcd_swizzled_pids,
    torch_gemm_mxfp,
)


# ---------------------------------------------------------------------------
# Refill issue.
#
# ``HALF`` selects the low or high K128 of logical tile ``tile_idx``.  Data and
# scale go out as two fused pairs, data first, matching the order the K256
# schedule measured best.

@gluon.jit
def splitk_issue_data(
        a_desc, b_desc, a_buf, b_buf, tile_idx, slot, HALF: gl.constexpr):
    tile_k = tile_idx * 256 + HALF * 128
    a_load = tdm.update_tensor_descriptor(a_desc, add_offsets=[0, tile_k])
    b_load = tdm.update_tensor_descriptor(b_desc, add_offsets=[0, tile_k])
    # B's 128-column accumulator partition gives it four logical pieces, and a
    # partitioned encoding's mask must select a multiple of four warps, so B
    # cannot take the two warps a fused pair would leave it. Warps 2, 3, 6, 7
    # satisfied the piece count but a TDM copy may only issue from warps 0-3.
    # Unfused, each copy takes all four; this is the third descriptor per half.
    tdm.async_load(
        a_load, [0, 0], a_buf.index(slot), warp_used_hint=0b00001111)
    tdm.async_load(
        b_load, [0, 0], b_buf.index(slot), warp_used_hint=0b00001111)


@gluon.jit
def splitk_issue_scale(
        as_desc, bs_desc, as_buf, bs_buf, tile_idx, slot, HALF: gl.constexpr):
    # Four block-32 scale entries per K128 half, preshuffled 128 wide.
    scale_k = tile_idx * 1024 + HALF * 512
    as_load = tdm.update_tensor_descriptor(as_desc, add_offsets=[0, scale_k])
    bs_load = tdm.update_tensor_descriptor(bs_desc, add_offsets=[0, scale_k])
    tdm.async_load_fused([
        (as_load, as_buf.index(slot), 0b00000011),
        (bs_load, bs_buf.index(slot), 0b00001100),
    ])


@gluon.jit
def splitk_read_half(
        a_buf, b_buf, as_buf, bs_buf, slot, DOT_A: gl.constexpr,
        DOT_B: gl.constexpr, SCALE_A_LAYOUT: gl.constexpr,
        SCALE_B_LAYOUT: gl.constexpr):
    """Read one whole half-slot: no K slicing, the buffer is already K128."""
    a = a_buf.index(slot).load(layout=DOT_A)
    a_scale = mxfp8_load_scale(as_buf, slot, 0, SCALE_A_LAYOUT, 1024, 4, 4)
    b = b_buf.index(slot).permute([1, 0]).load(layout=DOT_B)
    b_scale = mxfp8_load_scale(bs_buf, slot, 0, SCALE_B_LAYOUT, 1024, 4, 4)
    return a, a_scale, b, b_scale


# ---------------------------------------------------------------------------
# Per-tile schedules.
#
# Three variants rather than one constexpr-parameterised body: an earlier
# attempt to fold slot algebra behind constexpr predicates and
# ``gl.static_range`` miscompiled on this kernel family, passing 8 of 10 runs
# while being provably equivalent.  Straight-line indices are kept literal.

@gluon.jit
def splitk_consume_and_refill(
        a_ring, b_ring, as_ring, bs_ring, base, a_desc, b_desc, as_desc,
        bs_desc, tile_idx, acc, DOT_A: gl.constexpr, DOT_B: gl.constexpr,
        SCALE_A_LAYOUT: gl.constexpr, SCALE_B_LAYOUT: gl.constexpr,
        RING_WAIT: gl.constexpr):
    """Steady state: refill the next tile's high half, then t+2's low half."""
    tdm.async_wait(RING_WAIT)
    with gl.amd.warp_pipeline_stage("stage0", priority=0):
        # Half-slot base+3 is tile t+1's high half. Against the read of base it
        # is a different offset on the same base and modulus, so membar proves
        # the two disjoint and leaves this stage alone.
        gl.amd.gfx1250.cluster.arrive()
        gl.amd.gfx1250.cluster.wait()
        splitk_issue_data(
            a_desc, b_desc, a_ring, b_ring, tile_idx + 1, (base + 3) % 4, 1)
        splitk_issue_scale(
            as_desc, bs_desc, as_ring, bs_ring, tile_idx + 1,
            (base + 3) % 4, 1)
    # base+3 aliases the read one half-step back, across the loop edge, and the
    # ring is too shallow to give the refill more separation than that. Membar
    # can see the alias now but treats the wait's barrier above as covering it,
    # so the rendezvous the trailing waves need is placed here by hand.
    with gl.amd.warp_pipeline_stage("stage0", priority=0):
        a0, as0, b0, bs0 = splitk_read_half(
            a_ring, b_ring, as_ring, bs_ring, (base + 0) % 4, DOT_A, DOT_B,
            SCALE_A_LAYOUT, SCALE_B_LAYOUT)
    with gl.amd.warp_pipeline_stage("stage1", priority=1):
        acc = gl.amd.gfx1250.wmma_scaled(
            a0, as0, "e4m3", b0, bs0, "e4m3", acc)

    tdm.async_wait(RING_WAIT)
    with gl.amd.warp_pipeline_stage("stage0", priority=0):
        # Half-slot base+4 is tile t+2's low half, and base+4 reduces to base
        # under the modulus, so this refill aliases the read one half-step
        # above. Membar sees that and orders the two itself.
        gl.amd.gfx1250.cluster.arrive()
        gl.amd.gfx1250.cluster.wait()
        splitk_issue_data(
            a_desc, b_desc, a_ring, b_ring, tile_idx + 2, (base + 4) % 4, 0)
        splitk_issue_scale(
            as_desc, bs_desc, as_ring, bs_ring, tile_idx + 2,
            (base + 4) % 4, 0)
    # Same again: base+4 reduces to base, the slot the half-step above read.
    with gl.amd.warp_pipeline_stage("stage0", priority=0):
        a1, as1, b1, bs1 = splitk_read_half(
            a_ring, b_ring, as_ring, bs_ring, (base + 1) % 4, DOT_A, DOT_B,
            SCALE_A_LAYOUT, SCALE_B_LAYOUT)
    with gl.amd.warp_pipeline_stage("stage1", priority=1):
        acc = gl.amd.gfx1250.wmma_scaled(
            a1, as1, "e4m3", b1, bs1, "e4m3", acc)
    return acc


@gluon.jit
def splitk_consume_s1(
        a_ring, b_ring, as_ring, bs_ring, base, a_desc, b_desc, as_desc,
        bs_desc, tile_idx, acc, DOT_A: gl.constexpr, DOT_B: gl.constexpr,
        SCALE_A_LAYOUT: gl.constexpr, SCALE_B_LAYOUT: gl.constexpr,
        RING_WAIT: gl.constexpr):
    """Schedule 1: arrive, reads, wait, refill -- all in one stage0 region."""
    tdm.async_wait(RING_WAIT)
    with gl.amd.warp_pipeline_stage("stage0", priority=0):
        gl.amd.gfx1250.cluster.arrive()
        a0, as0, b0, bs0 = splitk_read_half(
            a_ring, b_ring, as_ring, bs_ring, (base + 0) % 4, DOT_A, DOT_B,
            SCALE_A_LAYOUT, SCALE_B_LAYOUT)
        gl.amd.gfx1250.cluster.wait()
        splitk_issue_data(
            a_desc, b_desc, a_ring, b_ring, tile_idx + 1, (base + 3) % 4, 1)
        splitk_issue_scale(
            as_desc, bs_desc, as_ring, bs_ring, tile_idx + 1,
            (base + 3) % 4, 1)
    with gl.amd.warp_pipeline_stage("stage1", priority=1):
        acc = gl.amd.gfx1250.wmma_scaled(
            a0, as0, "e4m3", b0, bs0, "e4m3", acc)

    tdm.async_wait(RING_WAIT)
    with gl.amd.warp_pipeline_stage("stage0", priority=0):
        gl.amd.gfx1250.cluster.arrive()
        a1, as1, b1, bs1 = splitk_read_half(
            a_ring, b_ring, as_ring, bs_ring, (base + 1) % 4, DOT_A, DOT_B,
            SCALE_A_LAYOUT, SCALE_B_LAYOUT)
        gl.amd.gfx1250.cluster.wait()
        splitk_issue_data(
            a_desc, b_desc, a_ring, b_ring, tile_idx + 2, (base + 4) % 4, 0)
        splitk_issue_scale(
            as_desc, bs_desc, as_ring, bs_ring, tile_idx + 2,
            (base + 4) % 4, 0)
    with gl.amd.warp_pipeline_stage("stage1", priority=1):
        acc = gl.amd.gfx1250.wmma_scaled(
            a1, as1, "e4m3", b1, bs1, "e4m3", acc)
    return acc


@gluon.jit
def splitk_consume_s2(
        a_ring, b_ring, as_ring, bs_ring, base, a_desc, b_desc, as_desc,
        bs_desc, tile_idx, acc, DOT_A: gl.constexpr, DOT_B: gl.constexpr,
        SCALE_A_LAYOUT: gl.constexpr, SCALE_B_LAYOUT: gl.constexpr,
        RING_WAIT: gl.constexpr):
    """Schedule 2: reads, arrive, wait, refill -- all in one stage0 region."""
    tdm.async_wait(RING_WAIT)
    with gl.amd.warp_pipeline_stage("stage0", priority=0):
        a0, as0, b0, bs0 = splitk_read_half(
            a_ring, b_ring, as_ring, bs_ring, (base + 0) % 4, DOT_A, DOT_B,
            SCALE_A_LAYOUT, SCALE_B_LAYOUT)
        gl.amd.gfx1250.cluster.arrive()
        gl.amd.gfx1250.cluster.wait()
        splitk_issue_data(
            a_desc, b_desc, a_ring, b_ring, tile_idx + 1, (base + 3) % 4, 1)
        splitk_issue_scale(
            as_desc, bs_desc, as_ring, bs_ring, tile_idx + 1,
            (base + 3) % 4, 1)
    with gl.amd.warp_pipeline_stage("stage1", priority=1):
        acc = gl.amd.gfx1250.wmma_scaled(
            a0, as0, "e4m3", b0, bs0, "e4m3", acc)

    tdm.async_wait(RING_WAIT)
    with gl.amd.warp_pipeline_stage("stage0", priority=0):
        a1, as1, b1, bs1 = splitk_read_half(
            a_ring, b_ring, as_ring, bs_ring, (base + 1) % 4, DOT_A, DOT_B,
            SCALE_A_LAYOUT, SCALE_B_LAYOUT)
        gl.amd.gfx1250.cluster.arrive()
        gl.amd.gfx1250.cluster.wait()
        splitk_issue_data(
            a_desc, b_desc, a_ring, b_ring, tile_idx + 2, (base + 4) % 4, 0)
        splitk_issue_scale(
            as_desc, bs_desc, as_ring, bs_ring, tile_idx + 2,
            (base + 4) % 4, 0)
    with gl.amd.warp_pipeline_stage("stage1", priority=1):
        acc = gl.amd.gfx1250.wmma_scaled(
            a1, as1, "e4m3", b1, bs1, "e4m3", acc)
    return acc


@gluon.jit
def splitk_consume_s3(
        a_ring, b_ring, as_ring, bs_ring, base, a_desc, b_desc, as_desc,
        bs_desc, tile_idx, acc, DOT_A: gl.constexpr, DOT_B: gl.constexpr,
        SCALE_A_LAYOUT: gl.constexpr, SCALE_B_LAYOUT: gl.constexpr,
        RING_WAIT: gl.constexpr):
    """Schedule 3: reads then arrive in stage0; WMMA, wait, refill in stage1."""
    tdm.async_wait(RING_WAIT)
    with gl.amd.warp_pipeline_stage("stage0", priority=0):
        a0, as0, b0, bs0 = splitk_read_half(
            a_ring, b_ring, as_ring, bs_ring, (base + 0) % 4, DOT_A, DOT_B,
            SCALE_A_LAYOUT, SCALE_B_LAYOUT)
        gl.amd.gfx1250.cluster.arrive()
    with gl.amd.warp_pipeline_stage("stage1", priority=1):
        acc = gl.amd.gfx1250.wmma_scaled(
            a0, as0, "e4m3", b0, bs0, "e4m3", acc)
        gl.amd.gfx1250.cluster.wait()
        splitk_issue_data(
            a_desc, b_desc, a_ring, b_ring, tile_idx + 1, (base + 3) % 4, 1)
        splitk_issue_scale(
            as_desc, bs_desc, as_ring, bs_ring, tile_idx + 1,
            (base + 3) % 4, 1)

    tdm.async_wait(RING_WAIT)
    with gl.amd.warp_pipeline_stage("stage0", priority=0):
        a1, as1, b1, bs1 = splitk_read_half(
            a_ring, b_ring, as_ring, bs_ring, (base + 1) % 4, DOT_A, DOT_B,
            SCALE_A_LAYOUT, SCALE_B_LAYOUT)
        gl.amd.gfx1250.cluster.arrive()
    with gl.amd.warp_pipeline_stage("stage1", priority=1):
        acc = gl.amd.gfx1250.wmma_scaled(
            a1, as1, "e4m3", b1, bs1, "e4m3", acc)
        gl.amd.gfx1250.cluster.wait()
        splitk_issue_data(
            a_desc, b_desc, a_ring, b_ring, tile_idx + 2, (base + 4) % 4, 0)
        splitk_issue_scale(
            as_desc, bs_desc, as_ring, bs_ring, tile_idx + 2,
            (base + 4) % 4, 0)
    return acc


@gluon.jit
def splitk_consume_refill_hi(
        a_ring, b_ring, as_ring, bs_ring, base, a_desc, b_desc, as_desc,
        bs_desc, tile_idx, acc, DOT_A: gl.constexpr, DOT_B: gl.constexpr,
        SCALE_A_LAYOUT: gl.constexpr, SCALE_B_LAYOUT: gl.constexpr,
        RING_WAIT: gl.constexpr):
    """Penultimate tile: the last tile's high half is still owed, t+2 is not."""
    tdm.async_wait(RING_WAIT)
    with gl.amd.warp_pipeline_stage("stage0", priority=0):
        gl.amd.gfx1250.cluster.arrive()
        gl.amd.gfx1250.cluster.wait()
        splitk_issue_data(
            a_desc, b_desc, a_ring, b_ring, tile_idx + 1, (base + 3) % 4, 1)
        splitk_issue_scale(
            as_desc, bs_desc, as_ring, bs_ring, tile_idx + 1,
            (base + 3) % 4, 1)
    with gl.amd.warp_pipeline_stage("stage0", priority=0):
        a0, as0, b0, bs0 = splitk_read_half(
            a_ring, b_ring, as_ring, bs_ring, (base + 0) % 4, DOT_A, DOT_B,
            SCALE_A_LAYOUT, SCALE_B_LAYOUT)
    with gl.amd.warp_pipeline_stage("stage1", priority=1):
        acc = gl.amd.gfx1250.wmma_scaled(
            a0, as0, "e4m3", b0, bs0, "e4m3", acc)

    with gl.amd.warp_pipeline_stage("stage0", priority=0):
        a1, as1, b1, bs1 = splitk_read_half(
            a_ring, b_ring, as_ring, bs_ring, (base + 1) % 4, DOT_A, DOT_B,
            SCALE_A_LAYOUT, SCALE_B_LAYOUT)
    with gl.amd.warp_pipeline_stage("stage1", priority=1):
        acc = gl.amd.gfx1250.wmma_scaled(
            a1, as1, "e4m3", b1, bs1, "e4m3", acc)
    return acc


@gluon.jit
def splitk_consume_tail(
        a_ring, b_ring, as_ring, bs_ring, base, acc,
        DOT_A: gl.constexpr, DOT_B: gl.constexpr,
        SCALE_A_LAYOUT: gl.constexpr, SCALE_B_LAYOUT: gl.constexpr):
    """Last tile: both halves are already resident and nothing is refilled."""
    with gl.amd.warp_pipeline_stage("stage0_tail", priority=0):
        a0, as0, b0, bs0 = splitk_read_half(
            a_ring, b_ring, as_ring, bs_ring, (base + 0) % 4, DOT_A, DOT_B,
            SCALE_A_LAYOUT, SCALE_B_LAYOUT)
    with gl.amd.warp_pipeline_stage("stage1_tail", priority=1):
        acc = gl.amd.gfx1250.wmma_scaled(
            a0, as0, "e4m3", b0, bs0, "e4m3", acc)
    with gl.amd.warp_pipeline_stage("stage0_tail", priority=0):
        a1, as1, b1, bs1 = splitk_read_half(
            a_ring, b_ring, as_ring, bs_ring, (base + 1) % 4, DOT_A, DOT_B,
            SCALE_A_LAYOUT, SCALE_B_LAYOUT)
    with gl.amd.warp_pipeline_stage("stage1_tail", priority=1):
        acc = gl.amd.gfx1250.wmma_scaled(
            a1, as1, "e4m3", b1, bs1, "e4m3", acc)
    return acc


# Two half-steps of refill stay in flight, three descriptors each: A data, B
# data, and the fused scale pair. The wait sits ahead of the issue, so only the
# halves already issued for later steps may remain outstanding, which is two.
#
# Moving the wait after the issue and raising this to 9 (three halves of lead)
# is correct but measured neutral: 329.4us against 328.9us at 4096x4096x65536.
# Unlike the two-slot K256 ring, where an ahead-of-issue wait collapses the
# count to 0, this four-slot ring already carries lead, so the placement buys
# nothing. Split-K's deficit is elsewhere: it is 19% behind the K256 deferred
# kernel's 275.6us, and halving the copy halves the contiguous transfer to 128
# bytes per row, which doubles GL2 requests.
SPLITK_RING_WAIT = gl.constexpr(6)


@gluon.jit
def mxfp8_splitk_kernel_gfx1250(
        a_ptr, b_ptr, c_ptr, a_scale_ptr, b_scale_ptr, M, N, K,
        stride_am, stride_ak, stride_bk, stride_bn, stride_cm, stride_cn,
        stride_scale, GRID_MN: gl.constexpr, SHARED_LAYOUT_A: gl.constexpr,
        SHARED_LAYOUT_B: gl.constexpr, SHARED_SCALE_A: gl.constexpr,
        SHARED_SCALE_B: gl.constexpr, WMMA_LAYOUT: gl.constexpr,
        SCHED: gl.constexpr = 0):
    gl.static_assert(gl.num_ctas() == 16)
    pid_m, pid_n = snapshot_get_xcd_swizzled_pids(
        M, N, 1024, 1024, GRID_MN, 8, 4)
    dot_a: gl.constexpr = gl.DotOperandLayout(0, WMMA_LAYOUT, 16)
    dot_b: gl.constexpr = gl.DotOperandLayout(1, WMMA_LAYOUT, 16)
    scale_a_layout: gl.constexpr = gl.amd.gfx1250.get_wmma_scale_layout(
        dot_a, [1024, 4])
    scale_b_layout: gl.constexpr = gl.amd.gfx1250.get_wmma_scale_layout(
        dot_b, [1024, 4])
    ring_wait: gl.constexpr = SPLITK_RING_WAIT
    # One four-slot ring rather than separate lo and hi pairs. The footprint is
    # identical, but every refill and every read then indexes the same
    # allocation, which is what lets membar's buffer index analysis compare
    # them: half-slot h holds the low half of tile h/2 when h is even and the
    # high half when odd, so tile t's halves are 2t and 2t+1.
    a_ring = gl.allocate_shared_memory(
        a_ptr.type.element_ty, [4, 1024, 128], SHARED_LAYOUT_A)
    b_ring = gl.allocate_shared_memory(
        b_ptr.type.element_ty, [4, 1024, 128], SHARED_LAYOUT_B)
    as_ring = gl.allocate_shared_memory(
        a_scale_ptr.type.element_ty, [4, 8, 512], SHARED_SCALE_A)
    bs_ring = gl.allocate_shared_memory(
        b_scale_ptr.type.element_ty, [4, 8, 512], SHARED_SCALE_B)
    a_desc = tdm.make_tensor_descriptor(
        base=a_ptr + pid_m * 1024 * stride_am, shape=(M, K),
        strides=(stride_am, stride_ak), block_shape=(1024, 128),
        layout=SHARED_LAYOUT_A)
    b_desc = tdm.make_tensor_descriptor(
        base=b_ptr + pid_n * 1024 * stride_bn, shape=(N, K),
        strides=(stride_bn, stride_bk), block_shape=(1024, 128),
        layout=SHARED_LAYOUT_B)
    as_desc = tdm.make_tensor_descriptor(
        base=a_scale_ptr + (pid_m * 1024) // 128 * stride_scale,
        shape=(M // 128, K // 32 * 128), strides=(stride_scale, 1),
        block_shape=(8, 512), layout=SHARED_SCALE_A)
    bs_desc = tdm.make_tensor_descriptor(
        base=b_scale_ptr + (pid_n * 1024) // 128 * stride_scale,
        shape=(N // 128, K // 32 * 128), strides=(stride_scale, 1),
        block_shape=(8, 512), layout=SHARED_SCALE_B)
    # Prologue: tile 0 needs both halves, and tile 1's low half has no
    # producer in the loop because the low refill runs two tiles ahead.
    splitk_issue_data(a_desc, b_desc, a_ring, b_ring, 0, 0, 0)
    splitk_issue_scale(as_desc, bs_desc, as_ring, bs_ring, 0, 0, 0)
    splitk_issue_data(a_desc, b_desc, a_ring, b_ring, 0, 1, 1)
    splitk_issue_scale(as_desc, bs_desc, as_ring, bs_ring, 0, 1, 1)
    splitk_issue_data(a_desc, b_desc, a_ring, b_ring, 1, 2, 0)
    splitk_issue_scale(as_desc, bs_desc, as_ring, bs_ring, 1, 2, 0)
    acc = gl.zeros((1024, 1024), dtype=gl.float32, layout=WMMA_LAYOUT)
    iter_max = gl.cdiv(K, 256)
    gl.assume(iter_max >= 2)
    for tile_idx in range(0, iter_max - 2):
        # Every index below is this one value plus a constant, reduced by a
        # constant modulus, which is the shape the analysis recognises.
        if SCHED == 0:
            acc = splitk_consume_and_refill(
                a_ring, b_ring, as_ring, bs_ring, tile_idx * 2, a_desc,
                b_desc, as_desc, bs_desc, tile_idx, acc, dot_a, dot_b,
                scale_a_layout, scale_b_layout, ring_wait)
        elif SCHED == 1:
            acc = splitk_consume_s1(
                a_ring, b_ring, as_ring, bs_ring, tile_idx * 2, a_desc,
                b_desc, as_desc, bs_desc, tile_idx, acc, dot_a, dot_b,
                scale_a_layout, scale_b_layout, ring_wait)
        elif SCHED == 2:
            acc = splitk_consume_s2(
                a_ring, b_ring, as_ring, bs_ring, tile_idx * 2, a_desc,
                b_desc, as_desc, bs_desc, tile_idx, acc, dot_a, dot_b,
                scale_a_layout, scale_b_layout, ring_wait)
        else:
            acc = splitk_consume_s3(
                a_ring, b_ring, as_ring, bs_ring, tile_idx * 2, a_desc,
                b_desc, as_desc, bs_desc, tile_idx, acc, dot_a, dot_b,
                scale_a_layout, scale_b_layout, ring_wait)
    pen_idx = iter_max - 2
    acc = splitk_consume_refill_hi(
        a_ring, b_ring, as_ring, bs_ring, pen_idx * 2, a_desc, b_desc,
        as_desc, bs_desc, pen_idx, acc, dot_a, dot_b, scale_a_layout,
        scale_b_layout, ring_wait)
    # The last tile carries no arrive/wait of its own, so it needs its own
    # rendezvous: its high half was refilled per CTA into distributed LDS.
    tdm.async_wait(0)
    snapshot_cluster_wait()
    acc = splitk_consume_tail(
        a_ring, b_ring, as_ring, bs_ring, (iter_max - 1) * 2, acc,
        dot_a, dot_b, scale_a_layout, scale_b_layout)
    # The serial output stage aliases cluster-distributed operand LDS. All CTAs
    # must finish the final operand reads before any CTA repurposes that arena.
    snapshot_cluster_wait()
    a_ring._keep_alive()
    b_ring._keep_alive()
    as_ring._keep_alive()
    bs_ring._keep_alive()
    mxfp8_tdm_store_serial_n2(
        c_ptr, pid_m, pid_n, stride_cm, stride_cn, M, N, acc)


def build_mxfp8_splitk_layouts():
    """Half-K operand layouts over the unchanged K256 WMMA derivation.

    The WMMA and accumulator layouts must stay identical to the K256 schedule,
    since the instruction shape and M/N partitioning are unchanged; only the
    shared operand buffers become K128.  So the WMMA layout is still derived
    from K256 padded layouts, while the buffers passed to the kernel are built
    from K128 ones.
    """
    cga_c = make_cga_layout([4, 4], [4, 4], [0, 1])
    local_a = gl.PaddedSharedLayout.with_identity_for(
        [[256, 16]], [1024, 256], [1, 0])
    local_b = gl.PaddedSharedLayout.with_identity_for(
        [[256, 16]], [1024, 256], [1, 0])
    _, _, local_wmma = gl.amd.gfx1250.make_partitioned_dot_layouts(
        1024, 1024, local_a, local_b, 8, [16, 16, 128],
        a_transposed=False, b_transposed=True, slice_m=256, slice_n=128)
    wmma = gl.amd.AMDWMMALayout(
        3, local_wmma.transposed, local_wmma.warp_bases,
        local_wmma.reg_bases, local_wmma.instr_shape, cga_c)
    dot_a = gl.DotOperandLayout(0, wmma, 16)
    dot_b = gl.DotOperandLayout(1, wmma, 16)
    cga_a = dot_a.cga_layout
    cga_b = tuple(tuple([basis[1], basis[0]])
                  for basis in dot_b.cga_layout)
    padded_a = gl.PaddedSharedLayout.with_identity_for(
        [[128, 16]], [1024, 128], [1, 0], cga_a)
    padded_b = gl.PaddedSharedLayout.with_identity_for(
        [[128, 16]], [1024, 128], [1, 0], cga_b)
    shared_a, shared_b, _ = gl.amd.gfx1250.make_partitioned_dot_layouts(
        256, 256, padded_a, padded_b, 8, [16, 16, 128],
        a_transposed=False, b_transposed=True, slice_m=256, slice_n=128)
    shared_as = gl.PaddedSharedLayout.with_identity_for(
        [[256, 8]], [8, 512], [1, 0], cga_a)
    shared_bs = gl.PaddedSharedLayout.with_identity_for(
        [[256, 8]], [8, 512], [1, 0], cga_b)
    return shared_a, shared_b, shared_as, shared_bs, wmma


def make_case(args):
    if args.M % 1024 or args.N % 1024 or args.K % 256:
        raise ValueError("MXFP8 requires M/N divisible by 1024 and K by 256")
    if args.K // 256 < 2:
        raise ValueError("MXFP8 requires at least two BK256 tiles")
    if args.M % 128 or args.N % 128 or (args.K // 32) % 4:
        raise ValueError("MXFP8 dimensions are incompatible with scale packing")
    torch.manual_seed(args.seed)
    if args.input_mode == "trig":
        a = make_trig_tensor((args.M, args.K), torch.float8_e4m3fn, False)
        b = make_trig_tensor((args.K, args.N), torch.float8_e4m3fn, True)
    else:
        a = init_data("float8_e4m3", args.M, args.K)
        b = init_data("float8_e4m3", args.K, args.N)
    scale_k = args.K // 32
    a_scale_obj = MXScaleTensor(
        size=(args.M, scale_k)).random(low=1.0, high=32.0)
    b_scale_obj = MXScaleTensor(
        size=(args.N, scale_k)).random(low=1.0, high=32.0)
    c_ref = None
    if args.check:
        c_ref = torch_gemm_mxfp(
            a, b, a_scale_obj, b_scale_obj, 32,
            args.M, args.N, args.K).to(torch.bfloat16)
    a_d = a.contiguous().cuda()
    b_d = b.T.contiguous().cuda()
    as_d = pack_scale(a_scale_obj.data, 4).cuda()
    bs_d = pack_scale(b_scale_obj.data, 4).cuda()
    c_d = torch.empty(
        (args.M, args.N), dtype=torch.bfloat16, device="cuda")
    layouts = build_mxfp8_splitk_layouts()
    grid = (triton.cdiv(args.M, 1024) * triton.cdiv(args.N, 1024), 1)

    def launch():
        shared_a, shared_b, shared_as, shared_bs, wmma = layouts
        return mxfp8_splitk_kernel_gfx1250[grid](
            a_d, b_d, c_d, as_d, bs_d, args.M, args.N, args.K,
            a_d.stride(0), a_d.stride(1), b_d.stride(1), b_d.stride(0),
            c_d.stride(0), c_d.stride(1), bs_d.stride(0),
            GRID_MN=grid[0], SHARED_LAYOUT_A=shared_a,
            SHARED_LAYOUT_B=shared_b, SHARED_SCALE_A=shared_as,
            SHARED_SCALE_B=shared_bs, WMMA_LAYOUT=wmma,
            SCHED=args.sched,
            num_warps=8, waves_per_eu=2, num_ctas=16,
            llvm_fn_attrs=AGPR_ATTRS)

    def check():
        c_d.zero_()
        launch()
        torch.cuda.synchronize()
        torch.testing.assert_close(c_d.cpu(), c_ref, rtol=1e-2, atol=5e-1)
        print("result verified", flush=True)

    return launch, check


def main():
    parser = argparse.ArgumentParser(
        description="MXFP8 split-K TDM refill schedule comparison")
    parser.add_argument("-M", type=int, default=4096)
    parser.add_argument("-N", type=int, default=4096)
    parser.add_argument("-K", type=int, default=65536)
    parser.add_argument(
        "--input-mode", choices=("random", "trig"), default="trig")
    parser.add_argument(
        "--sched", type=int, choices=(0, 1, 2, 3), default=0,
        help="0: refill and reads in separate stage0 regions (baseline); "
             "1: arrive, reads, wait, refill in one region; "
             "2: reads, arrive, wait, refill in one region; "
             "3: reads and arrive in stage0, WMMA, wait and refill in stage1")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--benchmark", action="store_true")
    parser.add_argument("--warmup", type=int, default=10)
    parser.add_argument("--probe-iters", type=int, default=20)
    parser.add_argument("--graph-ms", type=float, default=100.0)
    parser.add_argument("--replays", type=int, default=20)
    parser.add_argument("--iters-per-graph", type=int)
    args = parser.parse_args()
    if not args.check and not args.benchmark:
        parser.error("select --check and/or --benchmark")
    launch, check = make_case(args)
    if args.check:
        check()
    if args.benchmark:
        run_benchmark(launch, args.M, args.N, args.K, args)


if __name__ == "__main__":
    main()
